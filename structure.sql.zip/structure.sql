-- Adminer 4.8.0 MySQL 5.5.5-10.1.48-MariaDB-0+deb9u2 dump
-- 2021-08-30 08:41:25
SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `fn_accounts`;
CREATE TABLE `fn_accounts` (
  `account_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `status` int(4) DEFAULT '1',
  `name` varchar(400) DEFAULT NULL,
  `icon` varchar(145) DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL,
  `settings` text,
  `unread` text,
  `token_firebase` text,
  `interest_rate` decimal(5,2) DEFAULT NULL,
  `currency_unit` varchar(32) DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_account_report`;
CREATE TABLE `fn_account_report` (
  `account_id` bigint(20) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `month` varchar(2) NOT NULL,
  `year` varchar(4) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `counter` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_devices`;
CREATE TABLE `fn_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` text,
  `token_firebase` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_device_in_table`;
CREATE TABLE `fn_device_in_table` (
  `table_name` varchar(31) NOT NULL,
  `table_id` int(10) NOT NULL,
  `devices_table_id` int(11) NOT NULL,
  KEY `devices_table_id` (`devices_table_id`),
  CONSTRAINT `fn_device_in_table_ibfk_1` FOREIGN KEY (`devices_table_id`) REFERENCES `fn_devices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_events`;
CREATE TABLE `fn_events` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `assignee_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(245) DEFAULT NULL,
  `repeat` tinyint(1) DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  `note` text,
  `happen_at` datetime DEFAULT NULL,
  `lunar` tinyint(1) DEFAULT NULL,
  `priority` tinyint(1) DEFAULT NULL,
  `alarm` tinyint(1) DEFAULT NULL,
  `reminder_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_events_reminder`;
CREATE TABLE `fn_events_reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `time_send` datetime NOT NULL,
  `content` text NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `fn_notifications_ibfk_4` FOREIGN KEY (`event_id`) REFERENCES `fn_events` (`event_id`) ON DELETE CASCADE,
  CONSTRAINT `fn_notifications_ibfk_5` FOREIGN KEY (`account_id`) REFERENCES `fn_accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_event_categories`;
CREATE TABLE `fn_event_categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `icon` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `state` int(1) DEFAULT NULL,
  `parent` int(10) unsigned DEFAULT NULL,
  `level` int(10) unsigned DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `alias` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_event_display`;
CREATE TABLE `fn_event_display` (
  `event_id` bigint(20) unsigned NOT NULL,
  `display_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_homework`;
CREATE TABLE `fn_homework` (
  `homework_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `homework_item_id` bigint(20) unsigned NOT NULL,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `state` tinyint(3) unsigned NOT NULL,
  `owner_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `modified_at` datetime NOT NULL,
  `modified_by` bigint(20) unsigned NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`homework_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_homework_categories`;
CREATE TABLE `fn_homework_categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `icon` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `state` int(1) DEFAULT NULL,
  `parent` int(10) unsigned DEFAULT NULL,
  `level` int(10) unsigned DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `alias` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_homework_icons`;
CREATE TABLE `fn_homework_icons` (
  `icon_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `title_en` varchar(45) NOT NULL,
  `icon` varchar(45) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `modified_at` datetime NOT NULL,
  `modified_by` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`icon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_homework_items`;
CREATE TABLE `fn_homework_items` (
  `homework_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `icon` varchar(45) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `modified_at` datetime NOT NULL,
  `modified_by` bigint(20) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`homework_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_organizations`;
CREATE TABLE `fn_organizations` (
  `organization_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(400) DEFAULT NULL,
  `logo` text,
  `description` text,
  `holder` varchar(400) DEFAULT NULL,
  `account_name` varchar(400) DEFAULT NULL,
  `account_number` varchar(25) DEFAULT NULL,
  `bank_name` varchar(145) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `note` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `state` int(1) DEFAULT NULL,
  PRIMARY KEY (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_schedules`;
CREATE TABLE `fn_schedules` (
  `schedule_id` int(20) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(20) NOT NULL,
  `modified_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `happen_at_day` int(20) NOT NULL,
  `lesson` int(20) NOT NULL,
  `happen_at` varchar(255) NOT NULL,
  `priority` int(4) NOT NULL,
  `assignee_id` int(20) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_sessions`;
CREATE TABLE `fn_sessions` (
  `session_id` varchar(40) NOT NULL,
  `account_id` bigint(20) unsigned DEFAULT NULL,
  `start` int(11) NOT NULL DEFAULT '0',
  `end` int(11) NOT NULL DEFAULT '0',
  `device` text,
  `device_id` varchar(145) DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_share`;
CREATE TABLE `fn_share` (
  `share_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `transaction_id` bigint(20) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `modified_at` datetime NOT NULL,
  `modified_by` bigint(20) unsigned NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_subscriptions`;
CREATE TABLE `fn_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) unsigned DEFAULT NULL,
  `device_id` text,
  `transaction_id` varchar(255) NOT NULL,
  `transaction_token` text NOT NULL,
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `product_id` varchar(255) NOT NULL,
  `cancelled_date` datetime DEFAULT NULL,
  `response_from_store` text,
  `response_from_app` text,
  `response_store_at` datetime DEFAULT NULL,
  `response_app_at` datetime DEFAULT NULL,
  `modified_at` datetime NOT NULL,
  `success` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `fn_subscriptions_ibfk_3` FOREIGN KEY (`account_id`) REFERENCES `fn_accounts` (`account_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_traffic`;
CREATE TABLE `fn_traffic` (
  `traffic_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(400) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `head` text,
  `device` text,
  `device_id` varchar(145) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`traffic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `fn_transactions`;
CREATE TABLE `fn_transactions` (
  `transaction_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `modified_at` datetime NOT NULL,
  `modified_by` bigint(20) unsigned NOT NULL,
  `state` tinyint(1) NOT NULL,
  `note` text NOT NULL,
  `happen_at` datetime NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `fn_transaction_categories`;
CREATE TABLE `fn_transaction_categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `include` tinyint(1) NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `level` int(10) unsigned NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `alias` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `state` int(1) NOT NULL,
  `color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `fn_users`;
CREATE TABLE `fn_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `group` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_registered` datetime NOT NULL,
  `group_expired` datetime NOT NULL,
  `devices` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2021-08-30 08:41:25